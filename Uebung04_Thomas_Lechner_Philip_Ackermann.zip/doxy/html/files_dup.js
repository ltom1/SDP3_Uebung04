var files_dup =
[
    [ "Beispiel01", "dir_576ee90fa6b1b3db11cb9a5aebc1012e.html", "dir_576ee90fa6b1b3db11cb9a5aebc1012e" ]
];
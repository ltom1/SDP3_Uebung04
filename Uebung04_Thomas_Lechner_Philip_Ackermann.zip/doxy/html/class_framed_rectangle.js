var class_framed_rectangle =
[
    [ "UPtr", "class_framed_rectangle.html#af4fe9015d410146ecdae63baf42a2e0a", null ],
    [ "FramedRectangle", "class_framed_rectangle.html#afff9bf7a6d378a80dbe786925e0dcf50", null ],
    [ "GetProperties", "class_framed_rectangle.html#ab9ff7ab9c895f6afe292c289c6d722d1", null ]
];
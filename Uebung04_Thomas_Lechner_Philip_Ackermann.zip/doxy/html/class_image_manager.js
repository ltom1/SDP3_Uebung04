var class_image_manager =
[
    [ "AddCircle", "class_image_manager.html#a565babc4e11502c6ffd0a2297cec2cf5", null ],
    [ "AddImage", "class_image_manager.html#aecba1da9c13df43a81c99c0f202786e0", null ],
    [ "AddRectangle", "class_image_manager.html#ab0b5e670c1e5420b87dd86ee2ae98bfc", null ],
    [ "WriteAllSVG", "class_image_manager.html#a502911b8d601397b5b4743e1021bccde", null ]
];
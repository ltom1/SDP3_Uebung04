var annotated_dup =
[
    [ "Circle", "class_circle.html", "class_circle" ],
    [ "FilledCircle", "class_filled_circle.html", "class_filled_circle" ],
    [ "FilledObjectFactory", "class_filled_object_factory.html", "class_filled_object_factory" ],
    [ "FilledRectangle", "class_filled_rectangle.html", "class_filled_rectangle" ],
    [ "FramedCircle", "class_framed_circle.html", "class_framed_circle" ],
    [ "FramedObjectFactory", "class_framed_object_factory.html", "class_framed_object_factory" ],
    [ "FramedRectangle", "class_framed_rectangle.html", "class_framed_rectangle" ],
    [ "GraphicObject", "class_graphic_object.html", "class_graphic_object" ],
    [ "GraphicObjectFactory", "class_graphic_object_factory.html", "class_graphic_object_factory" ],
    [ "Image", "class_image.html", "class_image" ],
    [ "ImageManager", "class_image_manager.html", "class_image_manager" ],
    [ "Object", "class_object.html", "class_object" ],
    [ "Rectangle", "class_rectangle.html", "class_rectangle" ],
    [ "SingletonBase", "class_singleton_base.html", "class_singleton_base" ]
];
var indexSectionsWithContent =
{
  0: "acfgimorstuw~",
  1: "cfgiors",
  2: "acfgiorstw~",
  3: "m",
  4: "u"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "functions",
  3: "variables",
  4: "typedefs"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Functions",
  3: "Variables",
  4: "Typedefs"
};


var searchData=
[
  ['singletonbase_0',['SingletonBase',['../class_singleton_base.html#a3a1af84c8a61259494890bfdb0226208',1,'SingletonBase']]]
];

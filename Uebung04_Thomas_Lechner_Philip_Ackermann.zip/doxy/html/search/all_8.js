var searchData=
[
  ['singletonbase_0',['SingletonBase',['../class_singleton_base.html',1,'SingletonBase&lt; T &gt;'],['../class_singleton_base.html#a3a1af84c8a61259494890bfdb0226208',1,'SingletonBase::SingletonBase()']]],
  ['singletonbase_3c_20filledobjectfactory_20_3e_1',['SingletonBase&lt; FilledObjectFactory &gt;',['../class_singleton_base.html',1,'']]],
  ['singletonbase_3c_20framedobjectfactory_20_3e_2',['SingletonBase&lt; FramedObjectFactory &gt;',['../class_singleton_base.html',1,'']]],
  ['singletonbase_3c_20imagemanager_20_3e_3',['SingletonBase&lt; ImageManager &gt;',['../class_singleton_base.html',1,'']]]
];

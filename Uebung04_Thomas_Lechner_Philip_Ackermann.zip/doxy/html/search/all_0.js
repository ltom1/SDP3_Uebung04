var searchData=
[
  ['addcircle_0',['AddCircle',['../class_image.html#abe3165736e1226d187c5a11a1c009c66',1,'Image::AddCircle()'],['../class_image_manager.html#a565babc4e11502c6ffd0a2297cec2cf5',1,'ImageManager::AddCircle(size_t const x, size_t const y, std::string const &amp;color, size_t const radius)']]],
  ['addimage_1',['AddImage',['../class_image_manager.html#aecba1da9c13df43a81c99c0f202786e0',1,'ImageManager']]],
  ['addrectangle_2',['AddRectangle',['../class_image.html#a78ac3ad5284a3db03d6ccd8207adecd6',1,'Image::AddRectangle()'],['../class_image_manager.html#ab0b5e670c1e5420b87dd86ee2ae98bfc',1,'ImageManager::AddRectangle()']]]
];

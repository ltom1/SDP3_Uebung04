var searchData=
[
  ['writeallsvg_0',['WriteAllSVG',['../class_image_manager.html#a502911b8d601397b5b4743e1021bccde',1,'ImageManager']]],
  ['writetosvg_1',['WriteToSVG',['../class_image.html#aed9f8b50c65189e56522a84aca54c49b',1,'Image']]]
];

var class_image =
[
    [ "UPtr", "class_image.html#a07c341feaf749f6aac04bb8705136f51", null ],
    [ "Image", "class_image.html#a3c36872f34a1353102a1fc4b66e375c0", null ],
    [ "AddCircle", "class_image.html#abe3165736e1226d187c5a11a1c009c66", null ],
    [ "AddRectangle", "class_image.html#a78ac3ad5284a3db03d6ccd8207adecd6", null ],
    [ "WriteToSVG", "class_image.html#aed9f8b50c65189e56522a84aca54c49b", null ]
];
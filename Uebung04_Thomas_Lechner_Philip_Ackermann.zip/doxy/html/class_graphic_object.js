var class_graphic_object =
[
    [ "UPtr", "class_graphic_object.html#a0a6d99e8a15e98ecb4b06cc49a5126a1", null ],
    [ "GraphicObject", "class_graphic_object.html#acd2b5d7c7b1baf90fba3363db8ced461", null ],
    [ "GetProperties", "class_graphic_object.html#a98f48cc886272ad3e3302ea81d4cae44", null ],
    [ "ToSVG", "class_graphic_object.html#ad3ce3990589dfbe73fe35bc307903d1f", null ],
    [ "mColor", "class_graphic_object.html#a8255dc58ccd3bd36f71054b169efae48", null ],
    [ "mX", "class_graphic_object.html#a147fae164e41fa625ac010d0d772d47b", null ],
    [ "mY", "class_graphic_object.html#a2dbfca0a54a438cdf9aeb479586132b2", null ]
];
var class_rectangle =
[
    [ "UPtr", "class_rectangle.html#af8682d3aca6acc63e7df542579b27df6", null ],
    [ "Rectangle", "class_rectangle.html#a54e5964443082bc94cef5d89f5e18f92", null ],
    [ "ToSVG", "class_rectangle.html#a6a05d111c7ab0504c5a4415a9311bdc2", null ],
    [ "mHeight", "class_rectangle.html#a99875de312cdc85a38b3b18de15275a7", null ],
    [ "mWidth", "class_rectangle.html#a77c3cb84801c78488f5e0521f7d8dac2", null ]
];
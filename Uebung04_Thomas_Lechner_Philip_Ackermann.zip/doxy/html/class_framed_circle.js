var class_framed_circle =
[
    [ "UPtr", "class_framed_circle.html#adfa4d6669581578913967bd56183ceab", null ],
    [ "FramedCircle", "class_framed_circle.html#afbbff625c143b017cdb632e546419ec1", null ],
    [ "GetProperties", "class_framed_circle.html#ab8344a429198a25791b5a0b938ebe083", null ]
];
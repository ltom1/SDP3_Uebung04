var hierarchy =
[
    [ "GraphicObjectFactory", "class_graphic_object_factory.html", [
      [ "FilledObjectFactory", "class_filled_object_factory.html", null ],
      [ "FramedObjectFactory", "class_framed_object_factory.html", null ]
    ] ],
    [ "Object", "class_object.html", [
      [ "SingletonBase< FilledObjectFactory >", "class_singleton_base.html", [
        [ "FilledObjectFactory", "class_filled_object_factory.html", null ]
      ] ],
      [ "SingletonBase< FramedObjectFactory >", "class_singleton_base.html", [
        [ "FramedObjectFactory", "class_framed_object_factory.html", null ]
      ] ],
      [ "SingletonBase< ImageManager >", "class_singleton_base.html", [
        [ "ImageManager", "class_image_manager.html", null ]
      ] ],
      [ "GraphicObject", "class_graphic_object.html", [
        [ "Circle", "class_circle.html", [
          [ "FilledCircle", "class_filled_circle.html", null ],
          [ "FramedCircle", "class_framed_circle.html", null ]
        ] ],
        [ "Rectangle", "class_rectangle.html", [
          [ "FilledRectangle", "class_filled_rectangle.html", null ],
          [ "FramedRectangle", "class_framed_rectangle.html", null ]
        ] ]
      ] ],
      [ "Image", "class_image.html", null ],
      [ "SingletonBase< T >", "class_singleton_base.html", null ]
    ] ]
];
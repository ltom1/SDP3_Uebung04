var class_framed_object_factory =
[
    [ "FramedObjectFactory", "class_framed_object_factory.html#ad267c93cd4867124ba94b1e7451693fe", null ],
    [ "CreateCircle", "class_framed_object_factory.html#aec195b989367332b12ab5f96fa4d8fc6", null ],
    [ "CreateRectangle", "class_framed_object_factory.html#a633b4efcdc1a276be5d5d8844b36d0ef", null ]
];